#!/usr/bin/env bash
set -euo pipefail
root=${1:?}
cd "$root"
mkdir results
exec >results/remote.log 2>&1
started=$(date -u +%FT%TZ)
test "$(cat /proc/sys/kernel/tainted)" = 0
[[ $(cat /proc/cmdline) == *rauc.slot=B* ]]
printf 'Isolated OPi CSC experiment; no package mutation; kernel='
uname -r
sha256sum /usr/lib/aarch64-linux-gnu/librga.so.2 >results/system-before.sha256
dpkg-query -W -f='${Package} ${Version} ${Status}\n' librga2 gstreamer1.0-rockchip-ceralive >results/packages-before.txt
sha256sum bin/* lib/*/* >results/artifacts.sha256
for spec in retained:8:8080 fixed:0:0000 fixed:0:0808; do
  IFS=: read -r lib expected sequence <<<"$spec"
  name=$lib-$sequence
  mkdir "results/$name"
  env LD_LIBRARY_PATH="$root/lib/$lib" ldd "$root/bin/g-a-bench" >"results/$name/loader.txt"
  rc=0
  timeout -k 2 45 env CERALIVE_BOARD_TEST=1 LD_LIBRARY_PATH="$root/lib/$lib" \
    LD_PRELOAD="$root/bin/full709-selector.so" RGA_SELECTOR_DIR="$root/results/$name" \
    RGA_FULL709_EXPECT="$expected" RGA_FULL709_SEQUENCE="$sequence" \
    "$root/bin/g-a-bench" --improcess-only --iterations 4 --explicit-csc \
    >"results/$name/pixels.csv" 2>"results/$name/requests.log" || rc=$?
  printf '%s\n' "$rc" >"results/$name/client.exit"
  # The unmodified retained client still fails its known cold-session census.
  test "$rc" = 1
  test "$(grep -c '^completed=4 cell=' "results/$name/pixels.csv")" = 9
  grep -q '^fd_census_before=5 after=6$' "results/$name/pixels.csv"
  test "$(grep -c '^REQUEST ' "results/$name/requests.log")" = 36
  test "$(grep -c 'full709=1 .*delta=0/0/1 rc=0 ' "results/$name/requests.log")" = 4
done
sha256sum /usr/lib/aarch64-linux-gnu/librga.so.2 >results/system-after.sha256
dpkg-query -W -f='${Package} ${Version} ${Status}\n' librga2 gstreamer1.0-rockchip-ceralive >results/packages-after.txt
cmp results/system-before.sha256 results/system-after.sha256
cmp results/packages-before.txt results/packages-after.txt
test "$(cat /proc/sys/kernel/tainted)" = 0
journalctl -k --since "$started" -o cat >results/kernel-journal.txt
printf 'Isolated measurements collected; not a G-A/G-B or package-install pass.\n'
