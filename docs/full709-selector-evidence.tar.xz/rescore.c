#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "oracle.h"

static unsigned char input[1280 * 720 * 3];
static unsigned char output[1280 * 720 * 3 / 2];
static unsigned char reference[sizeof(output)];

static int load(const char *path, unsigned char *bytes, size_t size)
{
    FILE *f = fopen(path, "rb");
    if (!f) return 0;
    int ok = fread(bytes, size, 1, f) == 1 && fgetc(f) == EOF;
    return fclose(f) == 0 && ok;
}

int main(int argc, char **argv)
{
    if (argc != 5 || (strcmp(argv[3], "601") && strcmp(argv[3], "709")) ||
        (strcmp(argv[4], "limited") && strcmp(argv[4], "full"))) return 2;
    if (!load(argv[1], input, sizeof(input)) || !load(argv[2], output, sizeof(output))) return 2;
    enum oracle_matrix matrix = !strcmp(argv[3], "709") ? ORACLE_BT709 : ORACLE_BT601;
    enum oracle_range range = !strcmp(argv[4], "full") ? ORACLE_FULL : ORACLE_LIMITED;
    for (int y = 0; y < 720; y += 2) for (int x = 0; x < 1280; x += 2) {
        unsigned u = 0, v = 0;
        for (int j = 0; j < 2; ++j) for (int i = 0; i < 2; ++i) {
            const unsigned char *b = input + 3 * ((y + j) * 1280 + x + i);
            unsigned char rgb[3] = {b[2], b[1], b[0]}, yuv[3];
            oracle_rgb_to_yuv(rgb, yuv, matrix, range);
            reference[(y + j) * 1280 + x + i] = yuv[0];
            u += yuv[1]; v += yuv[2];
        }
        reference[1280 * 720 + y / 2 * 1280 + x] = (u + 2) / 4;
        reference[1280 * 720 + y / 2 * 1280 + x + 1] = (v + 2) / 4;
    }
    printf("%.6f\n", oracle_psnr(output, reference, sizeof(output)));
    return 0;
}
