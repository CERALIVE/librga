use strict;
use warnings;
use Digest::SHA qw(sha256_hex);

my ($root, $scorer) = @ARGV;
die "usage: verify.pl results rescore\n" unless defined $scorer;
my $checks = 0;
sub check { my ($ok, $why) = @_; die "FAIL: $why\n" unless $ok; ++$checks; }
sub read_file {
    open my $f, '<:raw', $_[0] or die "$!: $_[0]";
    local $/; my $s = <$f>; close $f or die $!; return $s;
}
my %outputs;
my $common_input;
for my $run ('retained-8080', 'fixed-0000', 'fixed-0808') {
    my ($sequence) = $run =~ /-(\d+)$/;
    my $from = $run =~ /^retained/ ? 8 : 0;
    my $dir = "$root/$run";
    my @pixels = grep { /,improcess,/ } split /\n/, read_file("$dir/pixels.csv");
    check(@pixels == 36, "$run 36 scored rows");
    my @requests = read_file("$dir/requests.log") =~ /^(REQUEST .*)$/mg;
    check(@requests == 36, "$run 36 requests");
    my %identities;
    my $full_req;
    for my $id (1 .. 36) {
        my $prefix = sprintf '%s/%03d', $dir, $id;
        my $a = read_file("$prefix-original.bin");
        my $b = read_file("$prefix-forwarded.bin");
        check(length($a) == 504 && length($b) == 504, "$run/$id full request size");
        my $want = $a;
        if ($id >= 33) {
            my $sel = substr($sequence, $id - 33, 1);
            check(ord(substr($a, 274, 1)) == $from, "$run/$id library selector");
            substr($want, 274, 1) = chr($sel);
            check($requests[$id-1] =~ /full709=1 selector=$from->$sel offset=274 size=504 core_mask=0 delta=0\/0\/1 rc=0 /,
                  "$run/$id same RGA2 core with real successful ioctl");
            $full_req //= $a;
            check($a eq $full_req, "$run/$id identical original full709 request across alternating calls");
        } else {
            check($requests[$id-1] =~ /full709=0 .*rc=0 /, "$run/$id unchanged successful control");
        }
        check($want eq $b, "$run/$id only byte274 can change, no normalization");
        next unless ($id >= 5 && $id <= 8) || $id >= 21;
        my ($cell, $api, $iteration, $time, $psnr) = split /,/, $pixels[$id-1];
        my ($matrix, $range) = $cell =~ /bgr-(601|709)-(limited|full)/;
        ($matrix, $range) = (601, 'limited') if $cell eq 'bgr-nv12';
        check(defined $matrix, "$run/$id known colour row");
        my $input = read_file("$prefix-input.bin");
        $common_input //= $input;
        check($input eq $common_input, "$run/$id input bytes identical across all captures");
        my $out = read_file("$prefix-output.bin");
        my $selector = ord(substr($b, 274, 1));
        my $key = "$cell/$selector";
        $outputs{$key} //= $out;
        check($out eq $outputs{$key}, "$run/$id identical output for same selector across libraries");
        my $expected = $matrix == 601 ? ($range eq 'limited' ? '52.776426' : '53.468170') :
                       $range eq 'limited' ? '52.904279' : $selector == 0 ? '50.689414' : '33.977872';
        check($psnr eq $expected, "$run/$id expected pixel recovery/control");
        open my $score, '-|', $scorer, "$prefix-input.bin", "$prefix-output.bin", $matrix, $range or die $!;
        my $measured = <$score>; close $score or die "scorer failed"; chomp $measured;
        check($measured eq $psnr, "$run/$id native oracle rescore matches unchanged client");
        print "$run,$cell,$iteration,$selector,$measured,",sha256_hex($out),"\n";
    }
    my $log = read_file("$dir/requests.log");
    for my $kind ('input', 'output') {
        my @ids = $log =~ /^BUFFER id=3[3-6] kind=$kind (.*)$/mg;
        check(@ids == 4 && $ids[0] eq $ids[1] && $ids[1] eq $ids[2] && $ids[2] eq $ids[3],
              "$run/$kind same DMA-BUF descriptor/device/inode/size");
    }
    check(read_file("$dir/client.exit") eq "1\n", "$run preserves known fd-census failure");
}
check($outputs{'bgr-709-full/0'} ne $outputs{'bgr-709-full/8'}, 'positive output-changing intervention');
check(read_file("$root/system-before.sha256") eq read_file("$root/system-after.sha256"), 'installed library unchanged');
check(read_file("$root/packages-before.txt") eq read_file("$root/packages-after.txt"), 'installed package records unchanged');
print "PASS assertions=$checks input_sha256=",sha256_hex($common_input),"\n";
